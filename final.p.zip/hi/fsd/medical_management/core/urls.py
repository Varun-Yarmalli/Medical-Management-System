from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('inventory/', views.inventory, name='inventory'),
    path('add_inventory/', views.add_inventory, name='add_inventory'),
    path('bill_generation/', views.bill_generation, name='bill_generation'),
    path('bill_details/<int:bill_id>/', views.bill_details, name='bill_details'),
    path('signup/', views.signup, name='signup'),
    path('login/', views.login_view, name='login'),
    path('update_inventory/<int:inventory_id>/', views.update_inventory, name='update_inventory'),
    path('delete_inventory/<int:inventory_id>/', views.delete_inventory, name='delete_inventory'),
    path('search_inventory/', views.search_inventory, name='search_inventory'),
    path('filter_bills/', views.filter_bills, name='filter_bills'),
    path('profile/', views.profile, name='profile'),
    path('bill-history/', views.bill_history, name='bill_history'),
    path('bill/<int:bill_id>/generate_pdf/', views.generate_pdf, name='generate_pdf')
    # path('login/', views.user_login, name='login'), 
]
