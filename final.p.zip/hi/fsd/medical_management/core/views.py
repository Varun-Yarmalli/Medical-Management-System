from turtle import color
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q
from django.core.paginator import Paginator
from core.models import Inventory, Bill,BillItem
from core.forms import SignUpForm
from django.contrib.auth.models import User
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

# Home page
def home(request):
    return render(request, 'home.html')


# Inventory page
@login_required
def inventory(request):
    items = Inventory.objects.all()
    return render(request, 'inventory.html', {'items': items})


# Add inventory page
@login_required
def add_inventory(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        description = request.POST.get('description')
        quantity = request.POST.get('quantity')
        price = request.POST.get('price')
        item = Inventory(name=name, description=description, quantity=quantity, price=price)
        item.save()
        return redirect('inventory')
    return render(request, 'add_inventory.html')


# Bill generation page
@login_required
# def bill_generation(request):
#     if request.method == 'POST':
#         patient_name = request.POST.get('patient_name')
#         items = request.POST.getlist('items')

#         # Ensure the user selected at least one item
#         if not patient_name or not items:
#             messages.error(request, "Patient name and at least one item are required.")
#             return redirect('bill_generation')

#         try:
#             # Fetch the items based on the provided item IDs
#             selected_items = Inventory.objects.filter(id__in=items)
#             total_amount = sum([float(item.price) for item in selected_items]*)

#             # Create and save the bill
#             bill = Bill(patient_name=patient_name, total_amount=total_amount)
#             bill.save()
#             bill.items.set(selected_items)
#             bill.save()

#             return redirect('bill_details', bill_id=bill.id)
#         except Inventory.DoesNotExist:
#             messages.error(request, "One or more items not found.")
#             return redirect('bill_generation')

#     inventory_items = Inventory.objects.all()
#     return render(request, 'bill_generation.html', {'inventory_items': inventory_items})


# def bill_generation(request):
#     if request.method == 'POST':
#         patient_name = request.POST.get('patient_name')
#         items = request.POST.getlist('items')
#         quantities = request.POST.getlist('quantities')  # Get quantities for each selected item

#         # Ensure the user selected at least one item
#         if not patient_name or not items:
#             messages.error(request, "Patient name and at least one item are required.")
#             return redirect('bill_generation')

#         if len(items) != len(quantities):
#             messages.error(request, "Mismatch between number of items and quantities.")
#             return redirect('bill_generation')

#         try:
#             # Fetch the items based on the provided item IDs
#             selected_items = Inventory.objects.filter(id__in=items)
            
#             total_amount = 0
#             for item_id, quantity in zip(items, quantities):
#                 item = selected_items.get(id=item_id)
#                 total_amount += float(item.price) * int(quantity)  # Calculate total price for each item

#             # Create and save the bill
#             bill = Bill(patient_name=patient_name, total_amount=total_amount)
#             bill.save()
#             bill.items.set(selected_items)
#             bill.save()

#             return redirect('bill_details', bill_id=bill.id)
#         except Inventory.DoesNotExist:
#             messages.error(request, "One or more items not found.")
#             return redirect('bill_generation')
#         except ValueError:
#             messages.error(request, "Invalid quantity or price.")
#             return redirect('bill_generation')

#     inventory_items = Inventory.objects.all()
#     return render(request, 'bill_generation.html', {'inventory_items': inventory_items})


# def bill_generation(request):
#     if request.method == 'POST':
#         patient_name = request.POST.get('patient_name')
#         items = request.POST.getlist('items')
#         quantities = request.POST.getlist('quantities')  # Get quantities for each selected item

#         # Ensure the user selected at least one item
#         if not patient_name or not items:
#             messages.error(request, "Patient name and at least one item are required.")
#             return redirect('bill_generation')

#         if len(items) != len(quantities):
#             messages.error(request, "Mismatch between number of items and quantities.")
#             return redirect('bill_generation')

#         try:
#             # Fetch the items based on the provided item IDs
#             selected_items = Inventory.objects.filter(id__in=items)
            
#             total_amount = 0
#             for item_id, quantity in zip(items, quantities):
#                 item = selected_items.get(id=item_id)
#                 total_amount += float(item.price) * int(quantity)  # Calculate total price for each item

#             # Create and save the bill
#             bill = Bill(patient_name=patient_name, total_amount=total_amount)
#             bill.save()

#             # Associate items and their quantities with the bill
#             for item_id, quantity in zip(items, quantities):
#                 item = selected_items.get(id=item_id)
#                 bill.items.add(item)  # Add item to the bill

#                 # Check if there is enough stock in inventory
#                 if item.stock >= int(quantity):
#                     item.stock -= int(quantity)  # Reduce the stock based on quantity sold
#                     item.save()  # Save the updated inventory item
#                 else:
#                     messages.error(request, f"Not enough stock for item: {item.name}.")
#                     return redirect('bill_generation')

#             bill.save()

#             return redirect('bill_details', bill_id=bill.id)
#         except Inventory.DoesNotExist:
#             messages.error(request, "One or more items not found.")
#             return redirect('bill_generation')
#         except ValueError:
#             messages.error(request, "Invalid quantity or price.")
#             return redirect('bill_generation')

#     inventory_items = Inventory.objects.all()
#     return render(request, 'bill_generation.html', {'inventory_items': inventory_items})

def bill_generation(request):
    if request.method == 'POST':
        patient_name = request.POST.get('patient_name')
        items = request.POST.getlist('items')
        quantities = request.POST.getlist('quantities')  # Get quantities for each selected item

        # Ensure the user selected at least one item
        if not patient_name or not items:
            messages.error(request, "Patient name and at least one item are required.")
            return redirect('bill_generation')

        if len(items) != len(quantities):
            messages.error(request, "Mismatch between number of items and quantities.")
            return redirect('bill_generation')

        try:
            # Fetch the items based on the provided item IDs
            selected_items = Inventory.objects.filter(id__in=items)
            
            total_amount = 0
            for item_id, quantity in zip(items, quantities):
                item = selected_items.get(id=item_id)
                total_amount += float(item.price) * int(quantity)  # Calculate total price for each item

            # Create and save the bill
            bill = Bill(patient_name=patient_name, total_amount=total_amount)
            bill.save()

            # Add items and quantities to the Bill using the BillItem model
            for item_id, quantity in zip(items, quantities):
                item = selected_items.get(id=item_id)
                # Create the relationship between the Bill and the Inventory item with quantity
                bill_item = BillItem(bill=bill, item=item, quantity=int(quantity))
                bill_item.save()

                # Check if there is enough quantity in inventory
                if item.quantity >= int(quantity):  # Replace 'stock' with 'quantity'
                    item.quantity -= int(quantity)  # Reduce the quantity based on the quantity sold
                    item.save()  # Save the updated inventory item
                else:
                    messages.error(request, f"Not enough quantity for item: {item.name}.")
                    return redirect('bill_generation')

            return redirect('bill_details', bill_id=bill.id)
        except Inventory.DoesNotExist:
            messages.error(request, "One or more items not found.")
            return redirect('bill_generation')
        except ValueError:
            messages.error(request, "Invalid quantity or price.")
            return redirect('bill_generation')

    inventory_items = Inventory.objects.all()
    return render(request, 'bill_generation.html', {'inventory_items': inventory_items})





# Bill details page
# @login_required
# def bill_details(request, bill_id):
#     bill = get_object_or_404(Bill, id=bill_id)
#     return render(request, 'bill_details.html', {'bill': bill})
from django.shortcuts import render, get_object_or_404
from .models import Bill

def bill_details(request, bill_id):
    # Fetch the bill based on the given ID
    bill = get_object_or_404(Bill, id=bill_id)
    
    # Get all the BillItems associated with this bill
    bill_items = bill.billitem_set.all()  # This gets all related BillItems for this bill

    # Pass the bill and items to the template
    return render(request, 'bill_details.html', {'bill': bill, 'bill_items': bill_items})


# Signup page
def signup(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            return redirect('login')
    else:
        form = SignUpForm()
    return render(request, 'signup.html', {'form': form})


# Login page
def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            messages.error(request, 'Invalid username or password.')

    return render(request, 'login.html')


# Search inventory
def search_inventory(request):
    query = request.GET.get('query', '')
    items = Inventory.objects.filter(Q(name_icontains=query) | Q(description_icontains=query))
    return render(request, 'inventory.html', {'items': items, 'query': query})


# Filter bills by date or patient
def filter_bills(request):
    query = request.GET.get('query', '')
    bills = Bill.objects.filter(Q(patient_name_icontains=query) | Q(created_at_date=query))
    return render(request, 'bill_history.html', {'bills': bills, 'query': query})


# User profile page (only for logged-in users)
@login_required
def profile(request):
    user_profile = request.user.userprofile
    if request.method == 'POST':
        user_profile.phone_number = request.POST.get('phone_number')
        user_profile.save()
        return redirect('profile')
    return render(request, 'profile.html', {'profile': user_profile})


# Bill history page with pagination
@login_required
def bill_history(request):
    bills_list = Bill.objects.all()
    paginator = Paginator(bills_list, 10)  # Show 10 bills per page
    page = request.GET.get('page')
    bills = paginator.get_page(page)
    return render(request, 'bill_history.html', {'bills': bills})


# Update inventory item
@login_required
def update_inventory(request, inventory_id):
    item = get_object_or_404(Inventory, id=inventory_id)
    if request.method == 'POST':
        item.name = request.POST.get('name')
        item.description = request.POST.get('description')
        item.quantity = request.POST.get('quantity')
        item.price = request.POST.get('price')
        item.save()
        return redirect('inventory')
    return render(request, 'update_inventory.html', {'item': item})


# Delete inventory item
@login_required
def delete_inventory(request, inventory_id):
    item = get_object_or_404(Inventory, id=inventory_id)
    item.delete()
    return redirect('inventory')

from django.http import HttpResponse

from .models import Bill, BillItem

# def generate_pdf(request, bill_id):
#     # Fetch the bill and associated items
#     bill = get_object_or_404(Bill, id=bill_id)
#     bill_items = bill.billitem_set.all()

#     # Create an HTTP response with PDF content type
#     response = HttpResponse(content_type='application/pdf')
#     response['Content-Disposition'] = f'inline; filename="bill_{bill_id}.pdf"'

#     # Create a canvas object to generate the PDF
#     p = canvas.Canvas(response, pagesize=letter)

#     # Set title and add text for the bill
#     p.setFont("Helvetica", 12)
#     p.drawString(100, 750, f"Bill ID: {bill.id}")
#     p.drawString(100, 735, f"Patient Name: {bill.patient_name}")
#     p.drawString(100, 720, f"Total Amount: ${bill.total_amount:.2f}")
    
#     # Add items to the PDF
#     y_position = 700
#     p.drawString(100, y_position, "Items Included:")
#     y_position -= 20

#     for item in bill_items:
#         p.drawString(100, y_position, f"{item.item.name} - Quantity: {item.quantity} - ${item.item.price} each")
#         y_position -= 15

#     # Finalize and save the PDF
#     p.showPage()
#     p.save()

#     return response

from django.http import HttpResponse
from reportlab.lib import colors 
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle
from .models import Bill, BillItem

def generate_pdf(request, bill_id):
    # Fetch the bill and associated items
    bill = get_object_or_404(Bill, id=bill_id)
    bill_items = bill.billitem_set.all()

    # Create an HTTP response with PDF content type
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'inline; filename="bill_{bill_id}.pdf"'

    # Create PDF document using SimpleDocTemplate
    document = SimpleDocTemplate(response, pagesize=letter)
    elements = []

    # Add Title Section (e.g., Bill ID, Patient Name, Total Amount)
    title = [["Bill ID", bill.id], ["Patient Name", bill.patient_name], ["Total Amount", f"${bill.total_amount:.2f}"]]

    # Create a table for the bill details
    data = [["Item", "Quantity", "Price", "Total"]]  # Table headers
    for item in bill_items:
        data.append([item.item.name, item.quantity, f"${item.item.price:.2f}", f"${item.item.price * item.quantity:.2f}"])

    # Creating the table with customized styles
    table = Table(data)
    table.setStyle(TableStyle([
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),  # Header text color
        ('BACKGROUND', (0, 0), (-1, 0), colors.darkblue),  # Header background color
        ('ALIGN', (1, 1), (-2, -2), 'CENTER'),  # Align all cells to the center
        ('GRID', (0, 0), (-1, -1), 1, colors.black),  # Add grid lines
        ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),  # Use Helvetica font for all text
        ('FONTSTYLE', (0, 0), (-1, 0), 'Bold'),  # Make header bold
    ]))
    elements.append(table)

    # Build the PDF
    document.build(elements)

    return response

